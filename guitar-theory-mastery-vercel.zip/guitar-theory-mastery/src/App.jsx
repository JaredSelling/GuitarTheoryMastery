
import React, { useEffect, useMemo, useRef, useState } from "react";
import { createClient } from "@supabase/supabase-js";

/** Minimal UI wrappers to replace shadcn/ui **/
function Button({ className="", ...props }) {
  const base = "inline-flex items-center justify-center px-3 py-2 rounded-xl border border-neutral-300 bg-white text-neutral-950 hover:bg-neutral-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white disabled:opacity-60";
  return <button className={base + " " + className} {...props} />;
}
function Card({ className="", children }) {
  return <div className={"rounded-2xl " + className}>{children}</div>;
}
function CardHeader({ children }) { return <div className="px-4 pt-4">{children}</div>; }
function CardTitle({ className="", children }) { return <h2 className={"text-xl font-bold " + className}>{children}</h2>; }
function CardContent({ className="", children }) { return <div className={"px-4 pb-4 " + className}>{children}</div>; }

// 🔐 Cloud persistence (Supabase) — expects env vars set at deploy time
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || ""; // Vercel can map NEXT_PUBLIC_* to VITE_* or set these directly
const supabaseAnon = import.meta.env.VITE_SUPABASE_ANON_KEY || "";
const supabase = (supabaseUrl && supabaseAnon) ? createClient(supabaseUrl, supabaseAnon) : null;

const SHARP_NOTES = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"];
const FLAT_TO_SHARP = { Db:"C#", Eb:"D#", Gb:"F#", Ab:"G#", Bb:"A#" };
const OPEN_STRINGS = { 6:"E", 5:"A", 4:"D", 3:"G", 2:"B", 1:"E" };

function normalizeNote(n){ const up=n.trim().replace(/\s+/g,"").toUpperCase(); return FLAT_TO_SHARP[up]||up; }
function noteIndex(note){ return SHARP_NOTES.indexOf(normalizeNote(note)); }
function transpose(note, semitones){ const idx=noteIndex(note); if(idx<0) return note; const out=(idx+semitones+1200)%12; return SHARP_NOTES[out]; }
function getNoteAt(str, fret){ const open = OPEN_STRINGS[str]; return transpose(open, fret); }
function shuffle(arr){ return [...arr].sort(()=>Math.random()-0.5); }
function randInt(min,max){ return Math.floor(Math.random()*(max-min+1))+min; }
function sample(arr){ return arr[randInt(0,arr.length-1)]; }

const lessons = [
  {
    id: 1, title: "Fretboard Landmarks & Notes",
    steps: [
      { type:"teach", title:"Your first landmarks", body:(
        <div className="space-y-3 text-neutral-100">
          <p>We’ll anchor the fretboard with <strong>landmarks</strong>: open strings and the 12th fret (octaves).</p>
          <ul className="list-disc list-inside text-neutral-100">
            <li>Open strings (6→1): E–A–D–G–B–E.</li>
            <li>12th fret is the same note name as open (one octave higher).</li>
            <li>Octave shape: same note appears <em>2 strings up and 2 frets higher</em> (except across G→B it’s +3 frets).</li>
          </ul>
          <p>Tip: Say notes out loud while you touch positions on your guitar. We’ll drill next.</p>
        </div>) },
      { type:"drill-note-name", title:"Name the note (0–12th fret)", settings:{ questions:12, passRate:0.85, strings:[6,5,4,3,2,1], frets:[...Array(13).keys()] } },
      { type:"teach", title:"Natural notes on 6th & 5th strings", body:(
        <div className="space-y-3 text-neutral-100">
          <p>Most root notes you’ll use live on the <strong>6th</strong> and <strong>5th</strong> strings. Learn their natural notes first:</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <Card className="bg-neutral-900 border border-neutral-700 text-neutral-100"><CardContent className="p-3 text-sm">
              <div className="font-semibold mb-1 text-neutral-50">6th string (E):</div>
              <div>E(0) – F(1) – G(3) – A(5) – B(7) – C(8) – D(10) – E(12)</div>
            </CardContent></Card>
            <Card className="bg-neutral-900 border border-neutral-700 text-neutral-100"><CardContent className="p-3 text-sm">
              <div className="font-semibold mb-1 text-neutral-50">5th string (A):</div>
              <div>A(0) – B(2) – C(3) – D(5) – E(7) – F(8) – G(10) – A(12)</div>
            </CardContent></Card>
          </div>
          <p>We’ll lock these in with another drill.</p>
        </div>) },
      { type:"drill-note-name", title:"Roots on 6th & 5th strings only", settings:{ questions:14, passRate:0.9, strings:[6,5], frets:[0,1,2,3,5,7,8,10,12] } },
      { type:"checkpoint", title:"Checkpoint: Fretboard basics", body:(
        <div className="space-y-2 text-neutral-100">
          <p>Pass this mixed quiz to unlock the next unit.</p>
          <ul className="list-disc list-inside"><li>Note naming anywhere 0–12th</li><li>Quick recall of 6th & 5th string naturals</li></ul>
        </div>), settings:{ questions:18, passRate:0.88, strings:[6,5,4,3,2,1], frets:[...Array(13).keys()] } },
    ]
  },
  { id:2, title:"Major Scale & Nashville Numbers",
    steps:[
      { type:"teach", title:"Formula & sound", body:(
        <div className="space-y-3 text-neutral-100">
          <p>The <strong>major scale</strong> uses the interval formula <code>W–W–H–W–W–W–H</code> (W=whole, H=half).</p>
          <p>Nashville Numbers label chords by scale degree. Diatonic triads: 1 (maj), 2 (min), 3 (min), 4 (maj), 5 (maj), 6 (min), 7° (dim).</p>
        </div>) },
      { type:"drill-degrees", title:"What is V in this key?", settings:{ questions:12, passRate:0.85 } },
      { type:"teach", title:"Build the notes of a key", body:(
        <div className="space-y-3 text-neutral-100">
          <p>Example, C major: C → D (W) → E (W) → F (H) → G (W) → A (W) → B (W) → C (H).</p>
          <p>On guitar, practice ascending/descending in 2 positions. Say the note names while you play.</p>
        </div>) },
      { type:"drill-scale-notes", title:"Name the 7 notes in the key", settings:{ questions:6, passRate:0.85 } },
      { type:"checkpoint", title:"Checkpoint: Major key fluency", body:(
        <div className="space-y-2 text-neutral-100">
          <p>Prove you can navigate keys with numbers and notes.</p>
          <ul className="list-disc list-inside"><li>Identify degrees (I–VII) in any key</li><li>List the 7 notes of a major key</li></ul>
        </div>), settings:{ questions:16, passRate:0.88 } },
    ]
  },
  { id:3, title:"Triads, CAGED & Chord-Scale Mapping",
    steps:[
      { type:"teach", title:"CAGED overview", body:(
        <div className="space-y-3 text-neutral-100">
          <p>The <strong>CAGED</strong> system links open shapes (C–A–G–E–D) to visualize chords/scales. We’ll map triad tones (1–3–5) so you can target chord tones.</p>
          <p>Focus on major triads on strings 1–3 and 2–4–5 groups first.</p>
        </div>) },
      { type:"drill-triad-tones", title:"Find chord tones (1–3–5)", settings:{ questions:12, passRate:0.85 } },
      { type:"checkpoint", title:"Checkpoint: Triad navigation", body:(<p className="text-neutral-100">Target chord tones in mixed prompts.</p>), settings:{ questions:14, passRate:0.86 } },
    ]
  },
  { id:4, title:"Identify the Key from Chords",
    steps:[
      { type:"teach", title:"Common progressions", body:(
        <div className="space-y-3 text-neutral-100">
          <p>Common moves: <code>I–IV–V</code>, <code>ii–V–I</code>, <code>I–vi–IV–V</code>.</p>
          <p>We’ll give you chord sets; you pick the most likely key.</p>
        </div>) },
      { type:"drill-key-by-chords", title:"What key fits these chords?", settings:{ questions:12, passRate:0.85 } },
      { type:"checkpoint", title:"Checkpoint: Key finder", body:(<p className="text-neutral-100">Pass to unlock the final unit.</p>), settings:{ questions:16, passRate:0.87 } },
    ]
  },
  { id:5, title:"Modes Lite & Improvisation Starter",
    steps:[
      { type:"teach", title:"Ionian → Mixolydian → Dorian", body:(
        <div className="space-y-3 text-neutral-100">
          <p>Start with three practical modes: Ionian (major), Mixolydian (major with b7), Dorian (minor with natural 6).</p>
          <p>We’ll map them to common chord types so you can solo immediately with purpose.</p>
        </div>) },
      { type:"drill-mode-match", title:"Pick the mode for the chord", settings:{ questions:10, passRate:0.85 } },
      { type:"checkpoint", title:"Final Checkpoint: Ready to Jam", body:(<p className="text-neutral-100">Show consistent choices on real progressions.</p>), settings:{ questions:18, passRate:0.88 } },
    ]
  },
];

function MultipleChoice({ options, onChoose }){
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-3">
      {options.map((opt,i)=>(
        <Button key={i} onClick={()=>onChoose(opt)} className="w-full">{opt}</Button>
      ))}
    </div>
  );
}
function useDrillState(total){
  const [q,setQ]=useState(0); const [correct,setCorrect]=useState(0); const [history,setHistory]=useState([]);
  function record(ok,prompt,answer,choice){
    setHistory(h=>[...h,{ok,prompt,answer,choice}]); setQ(q+1); if(ok) setCorrect(c=>c+1);
  }
  return { q, correct, record, history };
}

function DrillNoteName({ settings, onDone }){
  const total=settings.questions; const { q, correct, record, history }=useDrillState(total);
  const prompt=useMemo(()=>{
    const str=sample(settings.strings), fret=sample(settings.frets), ans=getNoteAt(str,fret);
    const pool=new Set([ans]); while(pool.size<4) pool.add(transpose(ans,[1,2,3,4,-1,-2,-3,-4][randInt(0,7)]));
    return { str, fret, ans, options: shuffle([...pool]) };
  },[q]);
  function choose(opt){ const ok=normalizeNote(opt)===normalizeNote(prompt.ans); record(ok,`String ${prompt.str}, fret ${prompt.fret}`,prompt.ans,opt); if(q+1>=total){ const score=(ok?correct+1:correct)/total; onDone(score>=settings.passRate);} }
  return (<div>
    <div className="text-lg font-semibold text-neutral-50">What note is this?</div>
    <div className="mt-2 p-3 rounded-xl bg-neutral-900 border border-neutral-700 text-neutral-50">String <b>{prompt.str}</b>, Fret <b>{prompt.fret}</b></div>
    <MultipleChoice options={prompt.options} onChoose={choose} />
    <ProgressFooter q={q} total={total} correct={correct} />
    <DrillHistory history={history} />
  </div>);
}

const MAJOR_KEYS = SHARP_NOTES;
const DEGREE_NUMBERS=["I","ii","iii","IV","V","vi","vii°"];
const DEGREE_SEMITONES=[0,2,4,5,7,9,11];
function degreeAnswer(key,degIndex){ return transpose(key, DEGREE_SEMITONES[degIndex]); }
function DrillDegrees({ settings, onDone }){
  const total=settings.questions; const { q, correct, record, history }=useDrillState(total);
  const prompt=useMemo(()=>{
    const key=sample(MAJOR_KEYS); const degIndex=randInt(0,6); const ans=degreeAnswer(key,degIndex);
    const pool=new Set([ans]); while(pool.size<4) pool.add(SHARP_NOTES[randInt(0,11)]);
    return { key, deg: DEGREE_NUMBERS[degIndex], ans, options: shuffle([...pool]) };
  },[q]);
  function choose(opt){ const ok=normalizeNote(opt)===normalizeNote(prompt.ans); record(ok,`${prompt.deg} in ${prompt.key}`,prompt.ans,opt); if(q+1>=total){ const score=(ok?correct+1:correct)/total; onDone(score>=settings.passRate);} }
  return (<div>
    <div className="text-lg font-semibold text-neutral-50">Which note is {prompt.deg} in key {prompt.key}?</div>
    <MultipleChoice options={prompt.options} onChoose={choose} />
    <ProgressFooter q={q} total={total} correct={correct} />
    <DrillHistory history={history} />
  </div>);
}

function buildMajorScale(key){ const semis=[0,2,4,5,7,9,11]; return semis.map(s=>transpose(key,s)); }
function DrillScaleNotes({ settings, onDone }){
  const total=settings.questions; const { q, correct, record, history }=useDrillState(total);
  const prompt=useMemo(()=>{
    const key=sample(MAJOR_KEYS); const scale=buildMajorScale(key); const missingIdx=randInt(0,6); const ans=scale[missingIdx];
    const pool=new Set([ans]); while(pool.size<4) pool.add(SHARP_NOTES[randInt(0,11)]);
    return { key, degree: missingIdx+1, ans, options: shuffle([...pool]), scale };
  },[q]);
  function choose(opt){ const ok=normalizeNote(opt)===normalizeNote(prompt.ans); record(ok,`Degree ${prompt.degree} of ${prompt.key}`,prompt.ans,opt); if(q+1>=total){ const score=(ok?correct+1:correct)/total; onDone(score>=settings.passRate);} }
  return (<div>
    <div className="text-lg font-semibold text-neutral-50">Key: {prompt.key} major — which note is degree {prompt.degree}?</div>
    <div className="mt-2 text-sm text-neutral-200">(Scale preview): {prompt.scale.join(" • ")}</div>
    <MultipleChoice options={prompt.options} onChoose={choose} />
    <ProgressFooter q={q} total={total} correct={correct} />
    <DrillHistory history={history} />
  </div>);
}

const DIATONIC_TRIADS=["maj","min","min","maj","maj","min","dim"];
function buildKeyChords(key){ const scale=buildMajorScale(key); return scale.map((n,i)=>`${n}${DIATONIC_TRIADS[i]==="maj"?"":DIATONIC_TRIADS[i]==="min"?"m":"°"}`); }
function randomProgression(key){ const options=[[1,4,5],[2,5,1],[1,6,4,5],[1,5,6,4],[4,1,5],[6,4,1,5]]; const degrees=sample(options); const chords=degrees.map(d=>buildKeyChords(key)[d-1]); return { degrees, chords }; }
function DrillKeyByChords({ settings, onDone }){
  const total=settings.questions; const { q, correct, record, history }=useDrillState(total);
  const prompt=useMemo(()=>{
    const key=sample(MAJOR_KEYS); const { chords }=randomProgression(key); const near=[transpose(key,2), transpose(key,5), transpose(key,-2)]; const opts=shuffle([key,...near]);
    return { chords, ans:key, options:opts };
  },[q]);
  function choose(opt){ const ok=normalizeNote(opt)===normalizeNote(prompt.ans); record(ok,`${prompt.chords.join(" - ")}`,prompt.ans,opt); if(q+1>=total){ const score=(ok?correct+1:correct)/total; onDone(score>=settings.passRate);} }
  return (<div>
    <div className="text-lg font-semibold text-neutral-50">Which key best fits these chords?</div>
    <div className="mt-2 p-3 rounded-xl bg-neutral-900 border border-neutral-700 text-neutral-50 text-sm">{prompt.chords.join("  •  ")}</div>
    <MultipleChoice options={prompt.options} onChoose={choose} />
    <ProgressFooter q={q} total={total} correct={correct} />
    <DrillHistory history={history} />
  </div>);
}

function DrillTriadTones({ settings, onDone }){
  const total=settings.questions; const { q, correct, record, history }=useDrillState(total);
  const prompt=useMemo(()=>{ const root=sample(SHARP_NOTES); const ans=transpose(root,4); const pool=shuffle([ans, transpose(root,3), transpose(root,5), transpose(root,7)]); return { root, ans, options: pool }; },[q]);
  function choose(opt){ const ok=normalizeNote(opt)===normalizeNote(prompt.ans); record(ok,`Major triad tones of ${prompt.root}`,prompt.ans,opt); if(q+1>=total){ const score=(ok?correct+1:correct)/total; onDone(score>=settings.passRate);} }
  return (<div>
    <div className="text-lg font-semibold text-neutral-50">What is the <span className="font-bold">3rd</span> of {prompt.root} major?</div>
    <MultipleChoice options={prompt.options} onChoose={choose} />
    <ProgressFooter q={q} total={total} correct={correct} />
    <DrillHistory history={history} />
  </div>);
}

function DrillModeMatch({ settings, onDone }){
  const total=settings.questions; const { q, correct, record, history }=useDrillState(total);
  const prompt=useMemo(()=>{ const mode=sample(["Ionian","Mixolydian","Dorian"]); const chord=mode==="Mixolydian"?"G7":mode==="Dorian"?"Am7":"Cmaj7"; const ans=mode; const options=shuffle(["Ionian","Mixolydian","Dorian","Phrygian"]); return { chord, ans, options }; },[q]);
  function choose(opt){ const ok=opt===prompt.ans; record(ok,`Chord ${prompt.chord}`,prompt.ans,opt); if(q+1>=total){ const score=(ok?correct+1:correct)/total; onDone(score>=settings.passRate);} }
  return (<div>
    <div className="text-lg font-semibold text-neutral-50">Which mode fits best over this chord?</div>
    <div className="mt-2 p-3 rounded-xl bg-neutral-900 border border-neutral-700 text-neutral-50 text-sm">Chord: {prompt.chord}</div>
    <MultipleChoice options={prompt.options} onChoose={choose} />
    <ProgressFooter q={q} total={total} correct={correct} />
    <DrillHistory history={history} />
  </div>);
}

function DrillHistory({ history }){
  if(!history.length) return null;
  return (<div className="mt-4 text-xs text-neutral-200">
    <div className="font-semibold text-neutral-50 mb-1">Your answers</div>
    <div className="max-h-36 overflow-auto pr-1 space-y-1">
      {history.map((h,i)=>(
        <div key={i} className={`flex items-center justify-between rounded-lg px-2 py-1 ${h.ok?"bg-green-900/30":"bg-red-900/30"}`}>
          <div className="truncate text-neutral-100">{h.prompt}</div>
          <div className="ml-2 shrink-0 text-neutral-100">{h.ok?"✅":"❌"} <span className="opacity-90">({h.choice})</span> → <span className="font-mono">{h.answer}</span></div>
        </div>
      ))}
    </div>
  </div>);
}
function ProgressFooter({ q,total,correct }){
  const pct=Math.round((correct/Math.max(1,q))*100);
  return (<div className="mt-4 flex items-center justify-between text-sm text-neutral-100">
    <div>Question {q}/{total}</div>
    <div>Current accuracy: <span className="font-bold text-neutral-50">{isNaN(pct)?0:pct}%</span></div>
  </div>);
}

function AuthBar({ session, onSignIn, onSignOut }){
  const [email,setEmail]=useState("");
  if(!supabase) return (<div className="rounded-xl border border-neutral-700 bg-neutral-900 px-3 py-2 text-neutral-50 text-sm">
    Cloud sync unavailable: set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY.
  </div>);
  return (<div className="rounded-xl border border-neutral-700 bg-neutral-900 px-3 py-2 text-neutral-50">
    {session?.user ? (
      <div className="flex items-center justify-between gap-3 text-sm">
        <div>Signed in as <span className="font-semibold">{session.user.email || session.user.id}</span></div>
        <div className="flex gap-2">
          <Button onClick={onSignOut}>Sign out</Button>
        </div>
      </div>
    ) : (
      <div className="flex flex-col sm:flex-row gap-2 items-stretch sm:items-center">
        <input type="email" placeholder="you@email.com" value={email} onChange={e=>setEmail(e.target.value)}
          className="flex-1 rounded-xl bg-neutral-950 border border-neutral-700 px-3 py-2 text-neutral-50 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-white" />
        <Button onClick={()=>onSignIn(email)}>Send magic link</Button>
      </div>
    )}
  </div>);
}

export default function App(){
  const [state,setState]=useState(()=>({ currentLessonIdx:0, currentStepIdx:0, masteredLessons:{} }));
  const [notice,setNotice]=useState(null);
  const [session,setSession]=useState(null);
  const saveTimer=useRef(null);

  const currentLesson=lessons[state.currentLessonIdx];
  const currentStep=currentLesson.steps[state.currentStepIdx];

  // Load any cached state
  useEffect(()=>{
    try{
      const raw=localStorage.getItem("guitar_theory_progress_v1");
      if(raw) setState(JSON.parse(raw));
    }catch{}
  },[]);
  // persist locally
  useEffect(()=>{
    try{ localStorage.setItem("guitar_theory_progress_v1", JSON.stringify(state)); }catch{}
  },[state]);

  // supabase auth & load
  useEffect(()=>{
    if(!supabase) return;
    supabase.auth.getSession().then(({ data })=> setSession(data.session ?? null));
    const { data: sub } = supabase.auth.onAuthStateChange((_e,sess)=> setSession(sess));
    return ()=> sub.subscription.unsubscribe();
  },[]);
  useEffect(()=>{
    (async()=>{
      if(!supabase || !session?.user) return;
      const { data, error } = await supabase.from("progress").select("state").eq("user_id", session.user.id).maybeSingle();
      if(!error && data?.state){ setState(data.state); }
      else{
        await supabase.from("progress").upsert({ user_id: session.user.id, state, updated_at: new Date().toISOString() }, { onConflict:"user_id" });
      }
    })();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session?.user?.id]);

  // debounced cloud save
  useEffect(()=>{
    if(!supabase || !session?.user) return;
    if(saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(async ()=>{
      await supabase.from("progress").upsert({ user_id: session.user.id, state, updated_at: new Date().toISOString() }, { onConflict:"user_id" });
    }, 500);
    return ()=> { if(saveTimer.current) clearTimeout(saveTimer.current); }
  }, [state, session?.user]);

  async function signIn(email){
    if(!supabase) return;
    if(!email){ setNotice("Enter an email to receive a magic link."); setTimeout(()=>setNotice(null),2500); return; }
    const { error } = await supabase.auth.signInWithOtp({ email, options:{ emailRedirectTo: window.location.href } });
    if(error) setNotice(`Sign-in error: ${error.message}`);
    else setNotice("📧 Magic link sent! Check your inbox.");
    setTimeout(()=>setNotice(null),3500);
  }
  async function signOut(){ if(!supabase) return; await supabase.auth.signOut(); setNotice("Signed out. Using local cache."); setTimeout(()=>setNotice(null),2500); }

  function goNextStepAuto(){
    const isLast = state.currentStepIdx >= currentLesson.steps.length-1;
    if(!isLast) setState(s=>({ ...s, currentStepIdx: s.currentStepIdx+1 }));
    else {
      setState(s=>({ ...s, masteredLessons:{ ...s.masteredLessons, [currentLesson.id]:true }, currentLessonIdx: Math.min(s.currentLessonIdx+1, lessons.length-1), currentStepIdx:0 }));
      setNotice("✅ Unit completed! The next unit is unlocked."); setTimeout(()=>setNotice(null),3000);
    }
  }
  function goPrevStep(){ setState(s=>({ ...s, currentStepIdx: Math.max(0, s.currentStepIdx-1) })); }
  function goNextStepManual(){ setState(s=>({ ...s, currentStepIdx: Math.min(currentLesson.steps.length-1, s.currentStepIdx+1) })); }
  function canEnterLesson(index){ if(index===0) return true; const prevId=lessons[index-1].id; return !!state.masteredLessons[prevId]; }
  function enterLesson(index){
    if(!canEnterLesson(index)){ setNotice("🔒 Locked. Pass the previous unit’s checkpoint first."); setTimeout(()=>setNotice(null),3000); return; }
    setState(s=>({ ...s, currentLessonIdx:index, currentStepIdx:0 }));
  }
  function resetCurrentUnit(){ setState(s=>({ ...s, currentStepIdx:0 })); setNotice("↩️ Unit reset to Step 1."); setTimeout(()=>setNotice(null),2000); }

  const masteredCount = Object.values(state.masteredLessons).filter(Boolean).length;
  const progressPct = Math.round(((masteredCount + (state.currentStepIdx/currentLesson.steps.length)) / lessons.length) * 100);

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-50 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <header className="mb-4 md:mb-6">
          <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight text-center text-neutral-50">🎸 Guitar Theory Mastery</h1>
          <p className="text-center text-neutral-100 mt-2 text-sm">Step-by-step tutor • Mastery gates • <span className="font-semibold">Cloud sync</span> + offline cache</p>
          {notice && (<div className="mt-3 rounded-xl border border-neutral-700 bg-neutral-900 px-3 py-2 text-neutral-50" role="status" aria-live="polite">{notice}</div>)}
        </header>

        <div className="mb-4">
          <AuthBar session={session} onSignIn={signIn} onSignOut={signOut} />
        </div>

        <div className="w-full h-3 bg-neutral-900 border border-neutral-700 rounded-full overflow-hidden shadow-inner">
          <div className="h-full bg-white" style={{ width: `${progressPct}%` }} />
        </div>
        <div className="mt-1 text-right text-xs text-neutral-100">{progressPct}%</div>

        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {lessons.map((L,i)=>{
            const locked=!canEnterLesson(i); const mastered=!!state.masteredLessons[L.id];
            return (
              <div key={L.id} onClick={()=>enterLesson(i)} role="button" tabIndex={0}
                   onKeyDown={(e)=>(e.key==='Enter'||e.key===' ' )&&enterLesson(i)}
                   className={`cursor-pointer outline-none focus:ring-2 focus:ring-white text-left rounded-2xl p-4 border transition shadow ${
                     mastered? "bg-green-900/40 border-green-600" : locked? "bg-neutral-900/90 border-neutral-700" : "bg-neutral-900 border-neutral-600 hover:border-neutral-400"
                   }`} aria-disabled={locked}>
                <div className="flex items-center justify-between">
                  <div className="font-semibold text-neutral-50">Unit {L.id}: {L.title}</div>
                  <div className="text-neutral-50">{mastered? "✅":"➡️"}</div>
                </div>
                {locked && (<div className="mt-2 text-xs text-neutral-100">Locked until previous unit is passed.</div>)}
              </div>
            );
          })}
        </div>

        <Card className="mt-6 bg-neutral-900/95 border border-neutral-700 shadow-2xl text-neutral-50">
          <CardHeader><CardTitle className="text-2xl text-neutral-50">Unit {currentLesson.id}: {currentLesson.title}</CardTitle></CardHeader>
          <CardContent>
            <div className="text-sm text-neutral-100 mb-3">Step {state.currentStepIdx + 1} of {currentLesson.steps.length}</div>

            <div className="flex flex-wrap items-center gap-2 mb-4">
              {currentLesson.steps.map((_,idx)=>(
                <button key={idx} onClick={()=>setState(s=>({ ...s, currentStepIdx: idx }))}
                        className={`h-3 w-3 rounded-full border ${idx===state.currentStepIdx? 'bg-white border-white':'bg-neutral-800 border-neutral-600 hover:border-neutral-400'}`}
                        aria-label={`Go to step ${idx+1}`} />
              ))}
            </div>

            <StepView step={currentStep} onPass={goNextStepAuto} />

            <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex gap-2">
                <Button onClick={goPrevStep}>← Previous</Button>
                <Button onClick={goNextStepManual}>Next →</Button>
              </div>
              <Button onClick={resetCurrentUnit}>Reset unit to Step 1</Button>
            </div>

            <div className="mt-2 text-xs text-neutral-400">(You can review any step. Unlocking the next unit still requires passing this unit’s checkpoint.)</div>
          </CardContent>
        </Card>

        <details className="mt-6 text-sm text-neutral-200">
          <summary className="cursor-pointer">Supabase setup (click to expand)</summary>
          <pre className="mt-2 whitespace-pre-wrap bg-neutral-900 border border-neutral-700 rounded-xl p-3 text-xs">{`-- SQL: create table + RLS
create table if not exists public.progress (
  user_id uuid primary key references auth.users(id) on delete cascade,
  state jsonb not null,
  updated_at timestamp with time zone not null default now()
);

alter table public.progress enable row level security;
create policy "Users can read own progress" on public.progress for select using (auth.uid() = user_id);
create policy "Users can upsert own progress" on public.progress for insert with check (auth.uid() = user_id);
create policy "Users can update own progress" on public.progress for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
`}</pre>
        </details>

        <div className="mt-6 text-xs text-neutral-100 text-center">Tip: say note names out loud, tap your foot, keep eyes on fret markers.</div>
      </div>
    </div>
  );
}

function StepView({ step, onPass }){
  if(step.type==="teach"){
    return (<div>
      <h3 className="text-xl font-bold mb-2 text-neutral-50">{step.title}</h3>
      <div className="text-sm leading-relaxed text-neutral-100">{step.body}</div>
      <Button onClick={()=>onPass()} className="mt-4 w-full">I practiced this — continue</Button>
    </div>);
  }
  if(step.type==="drill-note-name") return (<div><h3 className="text-xl font-bold mb-2 text-neutral-50">{step.title}</h3><DrillNoteName settings={step.settings} onDone={(p)=>p&&onPass()} /></div>);
  if(step.type==="drill-degrees") return (<div><h3 className="text-xl font-bold mb-2 text-neutral-50">{step.title}</h3><DrillDegrees settings={step.settings} onDone={(p)=>p&&onPass()} /></div>);
  if(step.type==="drill-scale-notes") return (<div><h3 className="text-xl font-bold mb-2 text-neutral-50">{step.title}</h3><DrillScaleNotes settings={step.settings} onDone={(p)=>p&&onPass()} /></div>);
  if(step.type==="drill-key-by-chords") return (<div><h3 className="text-xl font-bold mb-2 text-neutral-50">{step.title}</h3><DrillKeyByChords settings={step.settings} onDone={(p)=>p&&onPass()} /></div>);
  if(step.type==="drill-triad-tones") return (<div><h3 className="text-xl font-bold mb-2 text-neutral-50">{step.title}</h3><DrillTriadTones settings={step.settings} onDone={(p)=>p&&onPass()} /></div>);
  if(step.type==="drill-mode-match") return (<div><h3 className="text-xl font-bold mb-2 text-neutral-50">{step.title}</h3><DrillModeMatch settings={step.settings} onDone={(p)=>p&&onPass()} /></div>);
  if(step.type==="checkpoint") return (<div><h3 className="text-xl font-bold mb-2 text-neutral-50">{step.title} 🏁</h3><div className="text-sm mb-3 text-neutral-100">{step.body}</div>{step.settings && <DrillNoteName settings={step.settings} onDone={(p)=>p&&onPass()} />}</div>);
  return <div className="text-neutral-50">Unsupported step type.</div>;
}
